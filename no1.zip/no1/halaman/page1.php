
<p style="color: black; font-size: 25px; background-color:white;">PT. better food and drink adalah PT yang bergerak dibidang makanan dan minuman
		sebagai tempat yang nyaman untuk menikmati makanan dan minuman, sebagai tempat untuk melepas penat setelah seharian bekerja, dan menikmati makanan dan minuman sebagai tempat yang pas untuk berbincang dengan teman. yang terletak di kabupaten lebong, provinsi bengkulu. 

      </p>