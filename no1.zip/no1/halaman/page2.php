<CENTER>
<table border="1px" width="70%" cellpadding="5" cellspacing="0">
<tr>
	<th>No :</th>
	<th>Nama :</th>
	<th>Jabatan</th>
	<th>NO Hp:</th>
</tr>
<tr>
	<td>1.</td>
	<td>VIVIN TAMARA</td>
	<td>DIREKTUR UTAMA</td>
	<td>085269547144</td>
</tr>
<tr>
	<td>2.</td>
	<td>TANIA</td>
	<td>WAKIL DIREKTUR</td>
	<td>089026675397</td>
</tr>
<tr>
	<td>3.</td>
	<td>LEAONORE</td>
	<td>SEKRETARIS</td>
	<td>082190875478</td>
</tr>
<tr>
	<td>3.</td>
	<td>LITZI</td>
	<td>BENDAHARA</td>
	<td>081309843892</td>
</tr>

 </table>
</CENTER>